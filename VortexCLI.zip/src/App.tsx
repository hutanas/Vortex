import React, { useState } from 'react';

type CommandOutput = { command: string; result: string };

const commands: Record<string, (args: string[]) => string> = {
  help: () => 'Available commands: help, echo, about, clear',
  echo: (args) => args.join(' '),
  about: () => 'Vortex CLI Web Application by YourName',
};

export default function App() {
  const [history, setHistory] = useState<CommandOutput[]>([]);
  const [input, setInput] = useState('');
  
  const handleCommand = (cmdText: string) => {
    const [cmd, ...args] = cmdText.trim().split(/\s+/);
    if (cmd === 'clear') {
      setHistory([]);
      return;
    }
    let result = commands[cmd]?.(args) ?? `Unknown command: ${cmd}`;
    setHistory([...history, { command: cmdText, result }]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;
    handleCommand(input);
    setInput('');
  };

  return (
    <div style={{
      fontFamily: "monospace",
      background: "#18181a",
      height: "100vh",
      color: "#e6e6e6",
      display: "flex",
      flexDirection: "column",
      alignItems: "center"
    }}>
      <h1 style={{ margin: "30px 0 10px 0", letterSpacing: "4px" }}>VORTEX CLI</h1>
      <div style={{
        border: "1px solid #333",
        borderRadius: "8px",
        width: "90%",
        maxWidth: "650px",
        padding: "24px",
        background: "#111"
      }}>
        <div style={{
          minHeight: "300px",
          marginBottom: "8px",
          whiteSpace: "pre-line"
        }}>
          {history.map((h, i) => (
            <div key={i}>
              <div><span style={{color: "#54e1ec"}}>$ vortex</span> {h.command}</div>
              <div>{h.result}</div>
            </div>
          ))}
        </div>
        <form onSubmit={handleSubmit}>
          <span style={{color: "#54e1ec"}}>$ vortex</span> <input
            value={input}
            onChange={e => setInput(e.target.value)}
            autoFocus
            style={{
              background: "#18181a",
              color: "#e6e6e6",
              border: "none",
              fontSize: "1rem",
              outline: "none",
              width: "70%",
            }}
            placeholder='Type a command... ("help" for options)'
          />
        </form>
      </div>
      <div style={{marginTop: "18px", fontSize: "0.95em", color: "#888"}}>
        Powered by Vortex &middot; Try commands: <strong>help</strong>, <strong>about</strong>, <strong>echo hello world</strong>, <strong>clear</strong>
      </div>
    </div>
  );
}